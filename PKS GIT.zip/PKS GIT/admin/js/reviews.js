"use strict";

/* =========================================================
   PKS FOUNDATION ADMIN REVIEWS
   COMPLETE FRONTEND JAVASCRIPT
========================================================= */

(function () {

    let allReviews = [];
    let currentFilter = "all";

    /* =====================================================
       GET ADMIN TOKEN
    ===================================================== */

    function getAdminToken() {

        const keys = [
            "adminToken",
            "admin_token",
            "pksAdminToken",
            "pks_admin_token",
            "adminAuthToken",
            "admin_auth_token",
            "authToken",
            "token"
        ];

        for (const key of keys) {

            const localToken = localStorage.getItem(key);

            if (localToken) {
                return localToken;
            }

            const sessionToken = sessionStorage.getItem(key);

            if (sessionToken) {
                return sessionToken;
            }
        }

        return null;
    }


    /* =====================================================
       ELEMENTS
    ===================================================== */

    const container =
        document.getElementById("reviewsContainer");

    const totalElement =
        document.getElementById("totalReviews");

    const pendingElement =
        document.getElementById("pendingReviews");

    const approvedElement =
        document.getElementById("approvedReviews");

    const publicElement =
        document.getElementById("publicReviews");

    const logoutButton =
        document.getElementById("logoutButton");

    const filterButtons =
        document.querySelectorAll(".filter-btn");


    /* =====================================================
       ESCAPE HTML
    ===================================================== */

    function escapeHTML(value) {

        if (value === null || value === undefined) {
            return "";
        }

        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }


    /* =====================================================
       GET INITIALS
    ===================================================== */

    function getInitials(name) {

        if (!name) {
            return "S";
        }

        const parts = String(name)
            .trim()
            .split(/\s+/)
            .filter(Boolean);

        if (parts.length === 1) {

            return parts[0]
                .substring(0, 2)
                .toUpperCase();
        }

        return (
            parts[0].charAt(0) +
            parts[parts.length - 1].charAt(0)
        ).toUpperCase();
    }


    /* =====================================================
       FORMAT DATE
    ===================================================== */

    function formatDate(value) {

        if (!value) {
            return "Date unavailable";
        }

        const date = new Date(value);

        if (Number.isNaN(date.getTime())) {
            return "Date unavailable";
        }

        return date.toLocaleDateString(
            "en-IN",
            {
                day: "numeric",
                month: "short",
                year: "numeric"
            }
        );
    }


    /* =====================================================
       FORMAT TIME
    ===================================================== */

    function formatTime(value) {

        if (!value) {
            return "";
        }

        const date = new Date(value);

        if (Number.isNaN(date.getTime())) {
            return "";
        }

        return date.toLocaleTimeString(
            "en-IN",
            {
                hour: "numeric",
                minute: "2-digit",
                hour12: true
            }
        );
    }


    /* =====================================================
       FORMAT DATE + TIME
    ===================================================== */

    function formatDateTime(value) {

        const date = formatDate(value);
        const time = formatTime(value);

        if (!time) {
            return date;
        }

        return `${date}, ${time}`;
    }


    /* =====================================================
       STAR DISPLAY
    ===================================================== */

    function renderStars(rating) {

        const number = Math.max(
            0,
            Math.min(
                5,
                Number(rating) || 0
            )
        );

        let stars = "";

        for (let index = 1; index <= 5; index++) {

            if (index <= number) {
                stars += "★";
            } else {
                stars += "☆";
            }
        }

        return stars;
    }


    /* =====================================================
       STATUS CLASS
    ===================================================== */

    function statusClass(status) {

        if (status === "approved") {
            return "status-approved";
        }

        if (status === "rejected") {
            return "status-rejected";
        }

        return "status-pending";
    }


    /* =====================================================
       LOAD REVIEWS
    ===================================================== */

    async function loadReviews() {

        if (!container) {
            return;
        }

        const token = getAdminToken();

        if (!token) {

            showError(
                "Administrator authentication required.",
                true
            );

            return;
        }

        container.className = "loading-box";

        container.innerHTML = `
            <div style="text-align:center;padding:40px;">
                <strong>Loading reviews...</strong>
                <p>Please wait.</p>
            </div>
        `;

        try {

            const response = await fetch(
                "/api/admin/reviews",
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            "Bearer " + token,

                        "Accept":
                            "application/json"
                    }
                }
            );

            let data = null;

            try {
                data = await response.json();
            } catch (error) {
                data = null;
            }


            if (response.status === 401) {

                showError(
                    "Your administrator session has expired. Please login again.",
                    true
                );

                return;
            }


            if (!response.ok) {

                throw new Error(
                    data && data.message
                        ? data.message
                        : "Unable to load reviews."
                );
            }


            if (
                !data ||
                data.success !== true
            ) {

                throw new Error(
                    data && data.message
                        ? data.message
                        : "Unable to load reviews."
                );
            }


            allReviews =
                Array.isArray(data.reviews)
                    ? data.reviews
                    : [];


            updateStatistics(
                data.summary
            );

            renderReviews();

        } catch (error) {

            console.error(
                "Reviews loading error:",
                error
            );

            showError(
                error.message ||
                "Unable to load reviews."
            );
        }
    }


    /* =====================================================
       UPDATE STATISTICS
    ===================================================== */

    function updateStatistics(summary) {

        summary = summary || {};

        const total =
            summary.total !== undefined
                ? summary.total
                : allReviews.length;


        const pending =
            summary.pending !== undefined
                ? summary.pending
                : allReviews.filter(
                    review =>
                        review.status === "pending"
                ).length;


        const approved =
            summary.approved !== undefined
                ? summary.approved
                : allReviews.filter(
                    review =>
                        review.status === "approved"
                ).length;


        const publicCount =
            summary.publicReviews !== undefined
                ? summary.publicReviews
                : allReviews.filter(
                    review =>
                        review.status === "approved" &&
                        review.isPublic === true
                ).length;


        if (totalElement) {
            totalElement.textContent = total;
        }

        if (pendingElement) {
            pendingElement.textContent = pending;
        }

        if (approvedElement) {
            approvedElement.textContent = approved;
        }

        if (publicElement) {
            publicElement.textContent = publicCount;
        }
    }


    /* =====================================================
       RENDER REVIEWS
    ===================================================== */

    function renderReviews() {

        if (!container) {
            return;
        }

        let reviews = allReviews;


        if (currentFilter !== "all") {

            reviews =
                allReviews.filter(
                    review =>
                        String(
                            review.status || ""
                        ).toLowerCase() ===
                        currentFilter
                );
        }


        if (reviews.length === 0) {

            container.className =
                "empty-box";

            let message =
                "No reviews found.";


            if (currentFilter === "pending") {
                message =
                    "There are no pending reviews.";
            }


            if (currentFilter === "approved") {
                message =
                    "There are no approved reviews.";
            }


            if (currentFilter === "rejected") {
                message =
                    "There are no rejected reviews.";
            }


            container.innerHTML = `
                <div style="text-align:center;padding:50px;">
                    <div style="font-size:42px;margin-bottom:12px;">
                        ⭐
                    </div>

                    <h3>${escapeHTML(message)}</h3>

                    <p>
                        Reviews submitted by students
                        will appear here.
                    </p>
                </div>
            `;

            return;
        }


        container.className =
            "reviews-list";


        container.innerHTML =
            reviews
                .map(review =>
                    createReviewCard(review)
                )
                .join("");


        attachActionButtons();
    }


    /* =====================================================
       CREATE REVIEW CARD
    ===================================================== */

    function createReviewCard(review) {

        const id =
            review._id ||
            review.id ||
            "";


        const name =
            review.studentName ||
            (
                review.student &&
                review.student.name
            ) ||
            "Student";


        const code =
            review.studentCode ||
            (
                review.student &&
                review.student.studentCode
            ) ||
            "Student";


        const rating =
            Number(review.rating) || 0;


        const text =
            review.reviewText || "";


        const status =
            String(
                review.status ||
                "pending"
            ).toLowerCase();


        const safeStatus =
            [
                "pending",
                "approved",
                "rejected"
            ].includes(status)
                ? status
                : "pending";


        const initials =
            getInitials(name);


        let buttons = "";


        if (safeStatus !== "approved") {

            buttons += `
                <button
                    type="button"
                    class="action-btn approve-btn"
                    data-review-action="approve"
                    data-review-id="${escapeHTML(id)}"
                >
                    ✓ Approve
                </button>
            `;
        }


        if (safeStatus !== "rejected") {

            buttons += `
                <button
                    type="button"
                    class="action-btn reject-btn"
                    data-review-action="reject"
                    data-review-id="${escapeHTML(id)}"
                >
                    ✕ Reject
                </button>
            `;
        }


        return `
            <article
                class="review-card"
                data-review-id="${escapeHTML(id)}"
            >

                <div class="review-card-header">

                    <div class="review-student">

                        <div class="student-avatar">
                            ${escapeHTML(initials)}
                        </div>

                        <div>

                            <h3>
                                ${escapeHTML(name)}
                            </h3>

                            <span>
                                ${escapeHTML(code)}
                            </span>

                        </div>

                    </div>


                    <div class="review-rating">

                        <div class="stars">
                            ${renderStars(rating)}
                        </div>

                    </div>

                </div>


                <div class="review-text">

                    ${
                        text
                            ? escapeHTML(text)
                            : "<em>No written feedback provided.</em>"
                    }

                </div>


                <div class="review-meta">

                    <div>

                        <span
                            class="${statusClass(
                                safeStatus
                            )}"
                        >
                            ${escapeHTML(safeStatus)}
                        </span>

                        ${
                            review.isPublic === true
                                ? `
                                    <span class="public-badge">
                                        🌐 Public
                                    </span>
                                `
                                : ""
                        }

                    </div>


                    <span>
                        ${formatDateTime(
                            review.createdAt ||
                            review.updatedAt
                        )}
                    </span>

                </div>


                ${
                    buttons
                        ? `
                            <div class="review-actions">
                                ${buttons}
                            </div>
                        `
                        : ""
                }

            </article>
        `;
    }


    /* =====================================================
       ACTION BUTTONS
    ===================================================== */

    function attachActionButtons() {

        const buttons =
            document.querySelectorAll(
                "[data-review-action]"
            );


        buttons.forEach(button => {

            button.addEventListener(
                "click",
                function () {

                    const action =
                        button.dataset.reviewAction;


                    const id =
                        button.dataset.reviewId;


                    if (!id) {
                        return;
                    }


                    const status =
                        action === "approve"
                            ? "approved"
                            : "rejected";


                    updateReviewStatus(
                        id,
                        status,
                        button
                    );
                }
            );
        });
    }


    /* =====================================================
       UPDATE REVIEW
    ===================================================== */

    async function updateReviewStatus(
        reviewId,
        status,
        clickedButton
    ) {

        const token =
            getAdminToken();


        if (!token) {

            window.location.href =
                "/admin/login.html";

            return;
        }


        const cards =
            document.querySelectorAll(
                "[data-review-id]"
            );


        let card = null;


        cards.forEach(item => {

            if (
                String(
                    item.dataset.reviewId
                ) === String(reviewId)
            ) {
                card = item;
            }
        });


        const buttons =
            card
                ? card.querySelectorAll(
                    ".action-btn"
                )
                : [];


        buttons.forEach(button => {

            button.disabled = true;
            button.style.opacity = "0.6";
            button.style.cursor = "wait";
        });


        if (clickedButton) {

            clickedButton.textContent =
                status === "approved"
                    ? "Approving..."
                    : "Rejecting...";
        }


        try {

            const response =
                await fetch(
                    "/api/admin/reviews/" +
                    encodeURIComponent(
                        reviewId
                    ),
                    {
                        method: "PATCH",

                        headers: {
                            "Authorization":
                                "Bearer " + token,

                            "Content-Type":
                                "application/json",

                            "Accept":
                                "application/json"
                        },

                        body: JSON.stringify({
                            status: status
                        })
                    }
                );


            let data = null;


            try {
                data =
                    await response.json();
            } catch (error) {
                data = null;
            }


            if (response.status === 401) {

                alert(
                    "Your administrator session has expired. Please login again."
                );

                window.location.href =
                    "/admin/login.html";

                return;
            }


            if (!response.ok) {

                throw new Error(
                    data && data.message
                        ? data.message
                        : "Unable to update review."
                );
            }


            if (
                !data ||
                data.success !== true
            ) {

                throw new Error(
                    data && data.message
                        ? data.message
                        : "Unable to update review."
                );
            }


            /* =============================================
               UPDATE LOCAL REVIEW
            ============================================= */

            const index =
                allReviews.findIndex(
                    review =>
                        String(
                            review._id ||
                            review.id
                        ) ===
                        String(reviewId)
                );


            if (index !== -1) {

                allReviews[index].status =
                    status;

                allReviews[index].isPublic =
                    status === "approved";

                allReviews[index].reviewedAt =
                    new Date().toISOString();
            }


            updateStatistics();

            renderReviews();


        } catch (error) {

            console.error(
                "Review update error:",
                error
            );


            alert(
                error.message ||
                "Unable to update review."
            );


            buttons.forEach(button => {

                button.disabled = false;
                button.style.opacity = "";
                button.style.cursor = "";
            });


            renderReviews();
        }
    }


    /* =====================================================
       FILTER BUTTONS
    ===================================================== */

    filterButtons.forEach(button => {

        button.addEventListener(
            "click",
            function () {

                currentFilter =
                    button.dataset.filter ||
                    "all";


                filterButtons.forEach(item => {

                    item.classList.remove(
                        "active"
                    );
                });


                button.classList.add(
                    "active"
                );


                renderReviews();
            }
        );
    });


    /* =====================================================
       LOGOUT
    ===================================================== */

    if (logoutButton) {

        logoutButton.addEventListener(
            "click",
            function () {

                const confirmLogout =
                    window.confirm(
                        "Are you sure you want to logout?"
                    );


                if (!confirmLogout) {
                    return;
                }


                const keys = [
                    "adminToken",
                    "admin_token",
                    "pksAdminToken",
                    "pks_admin_token",
                    "adminAuthToken",
                    "admin_auth_token",
                    "authToken",
                    "token"
                ];


                keys.forEach(key => {

                    localStorage.removeItem(
                        key
                    );

                    sessionStorage.removeItem(
                        key
                    );
                });


                window.location.href =
                    "/admin/login.html";
            }
        );
    }


    /* =====================================================
       SHOW ERROR
    ===================================================== */

    function showError(
        message,
        redirect = false
    ) {

        if (!container) {
            return;
        }


        container.className =
            "empty-box";


        container.innerHTML = `
            <div style="text-align:center;padding:50px;">

                <div style="font-size:42px;margin-bottom:15px;">
                    ⚠️
                </div>

                <h3>
                    ${escapeHTML(message)}
                </h3>

                ${
                    redirect
                        ? `
                            <button
                                type="button"
                                id="reviewLoginButton"
                                class="action-btn approve-btn"
                                style="margin-top:20px;"
                            >
                                Go to Admin Login
                            </button>
                        `
                        : `
                            <button
                                type="button"
                                id="reviewRetryButton"
                                class="action-btn approve-btn"
                                style="margin-top:20px;"
                            >
                                Try Again
                            </button>
                        `
                }

            </div>
        `;


        if (redirect) {

            const loginButton =
                document.getElementById(
                    "reviewLoginButton"
                );


            if (loginButton) {

                loginButton.addEventListener(
                    "click",
                    function () {

                        window.location.href =
                            "/admin/login.html";
                    }
                );
            }

        } else {

            const retryButton =
                document.getElementById(
                    "reviewRetryButton"
                );


            if (retryButton) {

                retryButton.addEventListener(
                    "click",
                    loadReviews
                );
            }
        }
    }


    /* =====================================================
       START
    ===================================================== */

    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            loadReviews
        );

    } else {

        loadReviews();
    }

})();s