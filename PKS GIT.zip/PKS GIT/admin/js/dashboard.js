/* =========================================================
   PKS FOUNDATION - ADMIN DASHBOARD
   FIXED ADMIN SESSION / REDIRECT LOOP
   ========================================================= */

"use strict";

document.addEventListener("DOMContentLoaded", function () {

    const TOKEN_KEYS = [
        "adminToken",
        "admin_token",
        "pksAdminToken",
        "pks_admin_token",
        "adminAuthToken",
        "admin_auth_token",
        "authToken",
        "token"
    ];

    function getAdminToken() {
        for (const key of TOKEN_KEYS) {
            const localToken = localStorage.getItem(key);

            if (localToken) {
                return localToken;
            }

            const sessionToken = sessionStorage.getItem(key);

            if (sessionToken) {
                return sessionToken;
            }
        }

        return null;
    }

    function clearAdminTokens() {
        TOKEN_KEYS.forEach(function (key) {
            localStorage.removeItem(key);
            sessionStorage.removeItem(key);
        });

        localStorage.removeItem("adminName");
        localStorage.removeItem("adminUsername");
        localStorage.removeItem("adminRole");
    }

    async function apiRequest(endpoint, options) {

        options = options || {};

        const token = getAdminToken();

        if (!token) {
            throw new Error("NO_ADMIN_SESSION");
        }

        const headers = Object.assign(
            {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            options.headers || {}
        );

        const response = await fetch(
            "/api" + endpoint,
            Object.assign({}, options, {
                headers: headers
            })
        );

        let data = null;

        try {
            data = await response.json();
        } catch (error) {
            data = null;
        }

        /*
         * Only a genuine 401 means the administrator
         * session is invalid.
         */
        if (response.status === 401) {
            throw new Error("ADMIN_SESSION_INVALID");
        }

        if (!response.ok) {
            throw new Error(
                data && data.message
                    ? data.message
                    : "Server returned HTTP " + response.status + "."
            );
        }

        if (data && data.success === false) {
            throw new Error(
                data.message || "Request failed."
            );
        }

        return data;
    }

    function setText(id, value) {

        const element =
            document.getElementById(id);

        if (element) {
            element.textContent =
                value === undefined ||
                value === null
                    ? "0"
                    : String(value);
        }
    }

    function setAdminName(name) {

        const savedName =
            name ||
            localStorage.getItem("adminName") ||
            "Santosh Sir";

        const welcomeTitle =
            document.getElementById("welcomeTitle");

        if (welcomeTitle) {
            welcomeTitle.textContent =
                "Welcome, " + savedName + " 👋";
        }

        const sidebarName =
            document.getElementById("sidebarAdminName");

        if (sidebarName) {
            sidebarName.textContent =
                savedName;
        }
    }

    function setCurrentYear() {

        const year =
            document.getElementById("currentYear");

        if (year) {
            year.textContent =
                new Date().getFullYear();
        }
    }

    function setupLogout() {

        const logoutButton =
            document.getElementById("logoutButton");

        if (!logoutButton) {
            return;
        }

        logoutButton.addEventListener(
            "click",
            function () {

                clearAdminTokens();

                window.location.replace(
                    "/admin/login.html"
                );
            }
        );
    }

    function setupMobileMenu() {

        const button =
            document.getElementById(
                "mobileMenuButton"
            );

        const sidebar =
            document.getElementById(
                "adminSidebar"
            );

        const overlay =
            document.getElementById(
                "sidebarOverlay"
            );

        if (!button || !sidebar) {
            return;
        }

        function closeMenu() {

            sidebar.classList.remove(
                "open"
            );

            if (overlay) {
                overlay.classList.remove(
                    "open"
                );
            }
        }

        button.addEventListener(
            "click",
            function () {

                sidebar.classList.toggle(
                    "open"
                );

                if (overlay) {
                    overlay.classList.toggle(
                        "open"
                    );
                }
            }
        );

        if (overlay) {
            overlay.addEventListener(
                "click",
                closeMenu
            );
        }

        sidebar
            .querySelectorAll("a")
            .forEach(function (link) {

                link.addEventListener(
                    "click",
                    closeMenu
                );

            });
    }

    function setupNavigation() {

        const links =
            document.querySelectorAll(
                ".admin-nav-link"
            );

        const currentPath =
            window.location.pathname;

        links.forEach(function (link) {

            const href =
                link.getAttribute("href");

            if (!href) {
                return;
            }

            try {

                const linkPath =
                    new URL(
                        href,
                        window.location.origin
                    ).pathname;

                link.classList.toggle(
                    "active",
                    linkPath === currentPath
                );

            } catch (error) {
                // Ignore invalid optional links.
            }
        });
    }

    async function verifyAdminSession() {

        const token =
            getAdminToken();

        /*
         * No token at all:
         * send the user to login.
         */
        if (!token) {

            clearAdminTokens();

            window.location.replace(
                "/admin/login.html"
            );

            return false;
        }

        try {

            const data =
                await apiRequest(
                    "/admin/me"
                );

            if (
                data &&
                data.admin
            ) {

                const admin =
                    data.admin;

                if (admin.name) {
                    localStorage.setItem(
                        "adminName",
                        admin.name
                    );
                }

                if (admin.username) {
                    localStorage.setItem(
                        "adminUsername",
                        admin.username
                    );
                }

                if (admin.role) {
                    localStorage.setItem(
                        "adminRole",
                        admin.role
                    );
                }

                setAdminName(
                    admin.name
                );
            }

            return true;

        } catch (error) {

            console.error(
                "Administrator session check:",
                error
            );

            /*
             * IMPORTANT:
             *
             * Only clear the token if the server
             * explicitly returned HTTP 401.
             */
            if (
                error.message ===
                "ADMIN_SESSION_INVALID"
            ) {

                clearAdminTokens();

                window.location.replace(
                    "/admin/login.html"
                );

                return false;
            }

            /*
             * Network/server problem:
             * DO NOT redirect to login.
             */
            return true;
        }
    }

    async function loadDashboardData() {

        try {

            const data =
                await apiRequest(
                    "/admin/dashboard"
                );

            const dashboardData =
                data && data.data
                    ? data.data
                    : {};

            setText(
                "totalStudents",
                dashboardData.totalStudents || 0
            );

            setText(
                "presentToday",
                dashboardData.presentToday || 0
            );

            setText(
                "absentToday",
                dashboardData.absentToday || 0
            );

            setText(
                "newInquiries",
                dashboardData.newInquiries || 0
            );

        } catch (error) {

            console.error(
                "Dashboard data error:",
                error
            );

            /*
             * Do NOT redirect.
             */
        }
    }

    async function loadRecentStudents() {

        const table =
            document.getElementById(
                "recentStudentsTable"
            );

        if (!table) {
            return;
        }

        try {

            const data =
                await apiRequest(
                    "/admin/students"
                );

            const students =
                Array.isArray(
                    data && data.students
                )
                    ? data.students
                    : [];

            if (students.length === 0) {
                return;
            }

            table.innerHTML =
                students
                    .slice(0, 5)
                    .map(function (student) {

                        const name =
                            student.name || "—";

                        const code =
                            student.studentCode || "—";

                        const course =
                            student.course || "—";

                        const active =
                            student.isActive !== false;

                        return (
                            "<tr>" +

                                "<td>" +
                                    escapeHTML(name) +
                                "</td>" +

                                "<td>" +
                                    escapeHTML(code) +
                                "</td>" +

                                "<td>" +
                                    escapeHTML(course) +
                                "</td>" +

                                "<td>" +

                                    "<span class=\"status-badge " +

                                    (
                                        active
                                            ? "status-active"
                                            : "status-inactive"
                                    ) +

                                    "\">" +

                                    (
                                        active
                                            ? "Active"
                                            : "Inactive"
                                    ) +

                                    "</span>" +

                                "</td>" +

                            "</tr>"
                        );

                    })
                    .join("");

        } catch (error) {

            console.error(
                "Recent students error:",
                error
            );

            /*
             * Do NOT redirect.
             */
        }
    }

    function escapeHTML(value) {

        return String(value)
            .replace(
                /&/g,
                "&amp;"
            )
            .replace(
                /</g,
                "&lt;"
            )
            .replace(
                />/g,
                "&gt;"
            )
            .replace(
                /"/g,
                "&quot;"
            )
            .replace(
                /'/g,
                "&#039;"
            );
    }

    async function initializeDashboard() {

        setCurrentYear();

        setupLogout();

        setupMobileMenu();

        setupNavigation();

        const sessionValid =
            await verifyAdminSession();

        if (!sessionValid) {
            return;
        }

        /*
         * Administrator is authenticated.
         */
        await Promise.all([
            loadDashboardData(),
            loadRecentStudents()
        ]);
    }

    initializeDashboard();

});