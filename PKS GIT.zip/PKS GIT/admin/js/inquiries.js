/* =========================================================
   PKS FOUNDATION
   ADMIN ADMISSION INQUIRIES
========================================================= */

"use strict";


/* =========================================================
   GLOBAL STATE
========================================================= */

let inquiries = [];
let currentFilter = "all";


/* =========================================================
   DOM READY
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    setupEventListeners();

    loadInquiries();

});


/* =========================================================
   TOKEN
========================================================= */

function getAdminToken() {

    const keys = [
        "adminToken",
        "token",
        "jwtToken",
        "admin_token",
        "pksAdminToken",
        "pks_admin_token",
        "adminAuthToken",
        "admin_auth_token",
        "authToken",
        "accessToken"
    ];


    for (let i = 0; i < keys.length; i++) {

        const key = keys[i];


        const localToken =
            localStorage.getItem(key);

        if (localToken) {
            return localToken;
        }


        const sessionToken =
            sessionStorage.getItem(key);

        if (sessionToken) {
            return sessionToken;
        }

    }


    return null;
}


/* =========================================================
   EVENT LISTENERS
========================================================= */

function setupEventListeners() {


    /* -----------------------------------------------------
       REFRESH
    ----------------------------------------------------- */

    const refreshButton =
        document.getElementById("refreshButton");


    if (refreshButton) {

        refreshButton.addEventListener(
            "click",
            function () {

                loadInquiries();

            }
        );

    }


    /* -----------------------------------------------------
       LOGOUT
    ----------------------------------------------------- */

    const logoutButton =
        document.getElementById("logoutButton");


    if (logoutButton) {

        logoutButton.addEventListener(
            "click",
            function () {

                logoutAdmin();

            }
        );

    }


    /* -----------------------------------------------------
       FILTER BUTTONS
    ----------------------------------------------------- */

    document
        .querySelectorAll(".filter-btn")
        .forEach(function (button) {

            button.addEventListener(
                "click",
                function () {

                    const filter =
                        button.getAttribute(
                            "data-filter"
                        ) || "all";


                    currentFilter =
                        filter.toLowerCase();


                    document
                        .querySelectorAll(".filter-btn")
                        .forEach(function (item) {

                            item.classList.remove(
                                "active"
                            );

                        });


                    button.classList.add(
                        "active"
                    );


                    renderInquiries();

                }
            );

        });


    /* -----------------------------------------------------
       INQUIRY STATUS BUTTONS
       
       Event delegation is used because the inquiry
       cards are created dynamically after the API loads.
    ----------------------------------------------------- */

    const container =
        document.getElementById(
            "inquiriesContainer"
        );


    if (container) {

        container.addEventListener(
            "click",
            function (event) {


                const button =
                    event.target.closest(
                        ".action-btn"
                    );


                if (!button) {
                    return;
                }


                const inquiryId =
                    button.getAttribute(
                        "data-id"
                    );


                const newStatus =
                    button.getAttribute(
                        "data-status"
                    );


                if (!inquiryId || !newStatus) {

                    console.error(
                        "Inquiry ID or status missing."
                    );

                    return;

                }


                changeInquiryStatus(
                    inquiryId,
                    newStatus,
                    button
                );

            }
        );

    }

}


/* =========================================================
   LOAD INQUIRIES
========================================================= */

async function loadInquiries() {

    const container =
        document.getElementById(
            "inquiriesContainer"
        );


    const refreshButton =
        document.getElementById(
            "refreshButton"
        );


    if (container) {

        container.innerHTML = `
            <div class="loading">
                Loading inquiries...
            </div>
        `;

    }


    if (refreshButton) {
        refreshButton.disabled = true;
        refreshButton.textContent = "Loading...";
    }


    try {

        const token =
            getAdminToken();


        if (!token) {

            throw new Error(
                "Admin login session not found. Please login again."
            );

        }


        const response =
            await fetch(
                "/api/admin/inquiries",
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            "Bearer " + token,

                        "Content-Type":
                            "application/json"
                    },

                    cache: "no-store"
                }
            );


        const data =
            await response.json();


        console.log(
            "Inquiry response:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Unable to load inquiries."
            );

        }


        if (!data.success) {

            throw new Error(
                data.message ||
                "Unable to load inquiries."
            );

        }


        inquiries =
            Array.isArray(
                data.inquiries
            )
                ? data.inquiries
                : [];


        updateStatistics();

        renderInquiries();


    } catch (error) {

        console.error(
            "Error loading inquiries:",
            error
        );


        if (container) {

            container.innerHTML = `
                <div class="error-box">

                    <strong>
                        Unable to load inquiries.
                    </strong>

                    <br><br>

                    ${escapeHTML(
                        error.message
                    )}

                    <br><br>

                    Please login again and refresh this page.

                </div>
            `;

        }

    } finally {

        if (refreshButton) {

            refreshButton.disabled = false;
            refreshButton.textContent = "Refresh";

        }

    }

}


/* =========================================================
   GET STATUS
========================================================= */

function getStatus(inquiry) {

    if (
        !inquiry ||
        !inquiry.status
    ) {

        return "new";

    }


    const status =
        String(
            inquiry.status
        )
        .trim()
        .toLowerCase();


    if (
        status !== "new" &&
        status !== "contacted" &&
        status !== "closed"
    ) {

        return "new";

    }


    return status;

}


/* =========================================================
   UPDATE STATISTICS
========================================================= */

function updateStatistics() {

    let newCount = 0;
    let contactedCount = 0;
    let closedCount = 0;


    inquiries.forEach(
        function (inquiry) {

            const status =
                getStatus(inquiry);


            if (status === "new") {
                newCount++;
            }


            if (status === "contacted") {
                contactedCount++;
            }


            if (status === "closed") {
                closedCount++;
            }

        }
    );


    setNumber(
        "newInquiries",
        newCount
    );


    setNumber(
        "contactedInquiries",
        contactedCount
    );


    setNumber(
        "closedInquiries",
        closedCount
    );


    setNumber(
        "totalInquiries",
        inquiries.length
    );


    console.log(
        "Inquiry statistics:",
        {
            new: newCount,
            contacted: contactedCount,
            closed: closedCount,
            total: inquiries.length
        }
    );

}


/* =========================================================
   SET NUMBER
========================================================= */

function setNumber(
    id,
    value
) {

    const element =
        document.getElementById(id);


    if (element) {

        element.textContent =
            String(value);

    }

}


/* =========================================================
   RENDER INQUIRIES
========================================================= */

function renderInquiries() {

    const container =
        document.getElementById(
            "inquiriesContainer"
        );


    if (!container) {

        console.error(
            "inquiriesContainer was not found."
        );

        return;

    }


    let list =
        inquiries.slice();


    if (
        currentFilter !== "all"
    ) {

        list =
            inquiries.filter(
                function (inquiry) {

                    return (
                        getStatus(inquiry) ===
                        currentFilter
                    );

                }
            );

    }


    if (list.length === 0) {

        container.innerHTML = `
            <div class="empty">

                No inquiries found.

            </div>
        `;

        return;

    }


    let html = "";


    list.forEach(
        function (inquiry) {

            html +=
                createInquiryCard(
                    inquiry
                );

        }
    );


    container.innerHTML =
        html;

}


/* =========================================================
   CREATE CARD
========================================================= */

function createInquiryCard(
    inquiry
) {

    const id =
        inquiry._id ||
        inquiry.id ||
        "";


    const name =
        inquiry.name ||
        "Unknown Student";


    const phone =
        inquiry.phone ||
        "Not provided";


    const email =
        inquiry.email ||
        "Not provided";


    const course =
        inquiry.course ||
        "Not specified";


    const message =
        inquiry.message ||
        "No message";


    const status =
        getStatus(inquiry);


    const date =
        formatDate(
            inquiry.createdAt
        );


    return `
        <div
            class="inquiry-card"
            data-inquiry-id="${escapeHTML(id)}"
        >

            <div class="inquiry-top">

                <div>

                    <div class="student-name">
                        ${escapeHTML(name)}
                    </div>

                    <div class="date">
                        ${escapeHTML(date)}
                    </div>

                </div>


                <div>

                    <span
                        class="status-badge status-${escapeHTML(status)}"
                    >
                        ${escapeHTML(status)}
                    </span>

                </div>

            </div>


            <div class="details">


                <div class="detail">

                    <div class="detail-label">
                        Phone
                    </div>

                    <div class="detail-value">
                        ${escapeHTML(phone)}
                    </div>

                </div>


                <div class="detail">

                    <div class="detail-label">
                        Email
                    </div>

                    <div class="detail-value">
                        ${escapeHTML(email)}
                    </div>

                </div>


                <div class="detail">

                    <div class="detail-label">
                        Course
                    </div>

                    <div class="detail-value">
                        ${escapeHTML(course)}
                    </div>

                </div>


                <div class="detail">

                    <div class="detail-label">
                        Current Status
                    </div>

                    <div class="detail-value">
                        ${escapeHTML(status)}
                    </div>

                </div>


            </div>


            <div class="message-box">

                <div class="message-label">
                    Message
                </div>

                <div class="message">
                    ${escapeHTML(message)}
                </div>

            </div>


            <div class="action-area">

                <div class="action-title">
                    Update inquiry status
                </div>


                <div class="action-buttons">


                    <button
                        type="button"
                        class="action-btn new-btn ${
                            status === "new"
                                ? "current-status"
                                : ""
                        }"
                        data-id="${escapeHTML(id)}"
                        data-status="new"
                    >
                        New
                    </button>


                    <button
                        type="button"
                        class="action-btn contacted-btn ${
                            status === "contacted"
                                ? "current-status"
                                : ""
                        }"
                        data-id="${escapeHTML(id)}"
                        data-status="contacted"
                    >
                        Contacted
                    </button>


                    <button
                        type="button"
                        class="action-btn close-btn ${
                            status === "closed"
                                ? "current-status"
                                : ""
                        }"
                        data-id="${escapeHTML(id)}"
                        data-status="closed"
                    >
                        Closed
                    </button>


                </div>

            </div>

        </div>
    `;

}


/* =========================================================
   CHANGE ONE INQUIRY STATUS
========================================================= */

async function changeInquiryStatus(
    inquiryId,
    newStatus,
    clickedButton
) {

    console.log(
        "Changing inquiry:",
        inquiryId,
        newStatus
    );


    const allowedStatuses = [
        "new",
        "contacted",
        "closed"
    ];


    if (
        !allowedStatuses.includes(
            newStatus
        )
    ) {

        alert(
            "Invalid inquiry status."
        );

        return;

    }


    const card =
        clickedButton
            ? clickedButton.closest(
                ".inquiry-card"
            )
            : null;


    const buttons =
        card
            ? card.querySelectorAll(
                ".action-btn"
            )
            : [];


    buttons.forEach(
        function (button) {

            button.disabled = true;

        }
    );


    const originalText =
        clickedButton
            ? clickedButton.textContent
            : "";


    if (clickedButton) {

        clickedButton.textContent =
            "Saving...";

    }


    try {

        const token =
            getAdminToken();


        if (!token) {

            throw new Error(
                "Admin login session expired. Please login again."
            );

        }


        const response =
            await fetch(
                "/api/admin/inquiries/" +
                encodeURIComponent(
                    inquiryId
                ),
                {
                    method: "PATCH",

                    headers: {
                        "Authorization":
                            "Bearer " + token,

                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify({
                            status: newStatus
                        })
                }
            );


        const data =
            await response.json();


        console.log(
            "Status update response:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Could not update inquiry."
            );

        }


        if (!data.success) {

            throw new Error(
                data.message ||
                "Could not update inquiry."
            );

        }


        /*
         * Update ONLY the inquiry that
         * was clicked.
         */

        const index =
            inquiries.findIndex(
                function (item) {

                    const itemId =
                        item._id ||
                        item.id ||
                        "";


                    return (
                        String(itemId) ===
                        String(inquiryId)
                    );

                }
            );


        if (index !== -1) {

            if (data.inquiry) {

                inquiries[index] =
                    data.inquiry;

            } else {

                inquiries[index].status =
                    newStatus;

            }

        }


        updateStatistics();

        renderInquiries();


        console.log(
            "Inquiry successfully changed to:",
            newStatus
        );


    } catch (error) {

        console.error(
            "Status update error:",
            error
        );


        buttons.forEach(
            function (button) {

                button.disabled =
                    false;

            }
        );


        if (clickedButton) {

            clickedButton.textContent =
                originalText;

        }


        alert(
            "Status could not be changed.\n\n" +
            error.message
        );

    }

}


/* =========================================================
   LOGOUT
========================================================= */

function logoutAdmin() {

    const keys = [
        "adminToken",
        "token",
        "jwtToken",
        "admin_token",
        "pksAdminToken",
        "pks_admin_token",
        "adminAuthToken",
        "admin_auth_token",
        "authToken",
        "accessToken"
    ];


    keys.forEach(
        function (key) {

            localStorage.removeItem(
                key
            );

            sessionStorage.removeItem(
                key
            );

        }
    );


    window.location.href =
        "/admin/login.html";

}


/* =========================================================
   FORMAT DATE
========================================================= */

function formatDate(
    value
) {

    if (!value) {
        return "";
    }


    const date =
        new Date(value);


    if (
        isNaN(
            date.getTime()
        )
    ) {

        return "";

    }


    return date.toLocaleString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


/* =========================================================
   GLOBAL ACCESS
========================================================= */

window.loadInquiries =
    loadInquiries;

window.changeInquiryStatus =
    changeInquiryStatus;
