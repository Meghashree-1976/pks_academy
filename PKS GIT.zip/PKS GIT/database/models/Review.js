const mongoose = require("mongoose");

const reviewSchema = new mongoose.Schema(
    {
        student: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Student",
            required: false,
            default: null
        },

        studentCode: {
            type: String,
            trim: true,
            uppercase: true,
            default: ""
        },

        studentName: {
            type: String,
            trim: true,
            required: true,
            maxlength: 100
        },

        rating: {
            type: Number,
            required: true,
            min: 1,
            max: 5
        },

        reviewText: {
            type: String,
            trim: true,
            maxlength: 1000,
            default: ""
        },

        status: {
            type: String,
            enum: ["pending", "approved", "rejected"],
            default: "pending"
        },

        isPublic: {
            type: Boolean,
            default: false
        },

        reviewedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Admin",
            default: null
        },

        reviewedAt: {
            type: Date,
            default: null
        }
    },
    {
        timestamps: true
    }
);

reviewSchema.index({
    status: 1,
    createdAt: -1
});

reviewSchema.index({
    isPublic: 1,
    createdAt: -1
});

reviewSchema.index({
    student: 1
});

module.exports = mongoose.model("Review", reviewSchema);