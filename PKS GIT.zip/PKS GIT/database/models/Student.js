const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema(
    {
        studentCode: {
            type: String,
            required: true,
            unique: true,
            trim: true,
            uppercase: true
        },

        name: {
            type: String,
            required: true,
            trim: true
        },

        pinHash: {
            type: String,
            required: true
        },

        fatherName: {
            type: String,
            trim: true
        },

        motherName: {
            type: String,
            trim: true
        },

        fatherPhone: {
            type: String,
            trim: true
        },

        motherPhone: {
            type: String,
            trim: true
        },

        studentPhone: {
            type: String,
            trim: true
        },

        address: {
            type: String,
            trim: true
        },

        course: {
            type: String,
            trim: true
        },

        enrollmentDate: {
            type: Date,
            default: Date.now
        },

        isActive: {
            type: Boolean,
            default: true
        }
    },
    {
        timestamps: true
    }
);

module.exports = mongoose.model(
    "Student",
    studentSchema
);