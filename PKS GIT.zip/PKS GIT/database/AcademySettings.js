const mongoose = require("mongoose");

const academySettingsSchema = new mongoose.Schema(
    {
        academyName: {
            type: String,
            default: "PKS Computer Education",
            trim: true
        },

        latitude: {
            type: Number,
            required: true,
            min: -90,
            max: 90
        },

        longitude: {
            type: Number,
            required: true,
            min: -180,
            max: 180
        },

        radiusMeters: {
            type: Number,
            default: 100,
            min: 20,
            max: 1000
        },

        updatedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Admin",
            default: null
        }
    },
    {
        timestamps: true
    }
);

module.exports = mongoose.model(
    "AcademySettings",
    academySettingsSchema
);