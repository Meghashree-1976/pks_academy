const fs = require("fs");

const file = ".\\server\\server.js";

if (!fs.existsSync(file)) {
    console.error("? server.js not found.");
    process.exit(1);
}

let source = fs.readFileSync(file, "utf8");

/* ---------------------------------------------------------
   BACKUP
--------------------------------------------------------- */

const backup =
    ".\\server\\server-BEFORE-ADMIN-REVIEWS-FINAL.js";

fs.copyFileSync(file, backup);

console.log("? Backup created:");
console.log(backup);

/* ---------------------------------------------------------
   CHECK IF ADMIN ROUTES ALREADY EXIST
--------------------------------------------------------- */

if (
    source.includes('"/api/admin/reviews"') ||
    source.includes("'/api/admin/reviews'")
) {
    console.log("");
    console.log("?? Admin review routes already exist.");
    console.log("No changes were made.");
    process.exit(0);
}

/* ---------------------------------------------------------
   FIND EXISTING REVIEW SECTION
--------------------------------------------------------- */

const reviewHeading =
    "REVIEWS & RATINGS";

const headingPosition =
    source.indexOf(reviewHeading);

if (headingPosition === -1) {

    console.error(
        "? REVIEWS & RATINGS section was not found."
    );

    console.error(
        "Your server.js was NOT changed."
    );

    process.exit(1);
}

/*
   Find the beginning of the comment block containing
   REVIEWS & RATINGS.
*/
let insertPosition =
    source.lastIndexOf(
        "/*",
        headingPosition
    );

if (insertPosition === -1) {

    console.error(
        "? Could not locate review section start."
    );

    console.error(
        "Your server.js was NOT changed."
    );

    process.exit(1);
}

/* ---------------------------------------------------------
   ADMIN REVIEW ROUTES
--------------------------------------------------------- */

const adminReviewRoutes = `

/* =========================================================
   ADMIN REVIEW MANAGEMENT
========================================================= */

/*
   GET ALL REVIEWS
   Used by Admin Reviews page.
*/
app.get(
    "/api/admin/reviews",
    authenticateAdmin,
    async (req, res) => {

        try {

            const reviews =
                await Review.find()
                    .populate(
                        "student",
                        "studentCode name course"
                    )
                    .populate(
                        "reviewedBy",
                        "name username"
                    )
                    .sort({
                        createdAt: -1
                    });

            const total =
                reviews.length;

            const pending =
                reviews.filter(
                    review =>
                        review.status === "pending"
                ).length;

            const approved =
                reviews.filter(
                    review =>
                        review.status === "approved"
                ).length;

            const rejected =
                reviews.filter(
                    review =>
                        review.status === "rejected"
                ).length;

            const publicReviews =
                reviews.filter(
                    review =>
                        review.status === "approved" &&
                        review.isPublic === true
                );

            const averageRating =
                publicReviews.length > 0
                    ? Number(
                        (
                            publicReviews.reduce(
                                (sum, review) =>
                                    sum +
                                    Number(review.rating),
                                0
                            ) /
                            publicReviews.length
                        ).toFixed(1)
                    )
                    : 0;

            return res.json({

                success: true,

                reviews,

                summary: {

                    total,

                    pending,

                    approved,

                    rejected,

                    publicReviews:
                        publicReviews.length,

                    averageRating

                }

            });

        } catch (error) {

            console.error(
                "ADMIN REVIEWS ERROR:",
                error
            );

            return res.status(500).json({

                success: false,

                message:
                    "Unable to load reviews."

            });
        }
    }
);


/*
   APPROVE / REJECT REVIEW
*/
app.patch(
    "/api/admin/reviews/:id",
    authenticateAdmin,
    async (req, res) => {

        try {

            const status =
                typeof req.body.status === "string"
                    ? req.body.status
                        .trim()
                        .toLowerCase()
                    : "";

            if (
                status !== "approved" &&
                status !== "rejected"
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Status must be approved or rejected."

                });
            }

            const review =
                await Review.findById(
                    req.params.id
                );

            if (!review) {

                return res.status(404).json({

                    success: false,

                    message:
                        "Review not found."

                });
            }

            review.status =
                status;

            review.isPublic =
                status === "approved";

            if (
                req.admin &&
                req.admin.adminId
            ) {

                review.reviewedBy =
                    req.admin.adminId;

            }

            review.reviewedAt =
                new Date();

            await review.save();

            return res.json({

                success: true,

                message:
                    status === "approved"
                        ? "Review approved successfully."
                        : "Review rejected successfully.",

                review

            });

        } catch (error) {

            console.error(
                "REVIEW MODERATION ERROR:",
                error
            );

            return res.status(500).json({

                success: false,

                message:
                    "Unable to update review."

            });
        }
    }
);

`;

source =
    source.slice(
        0,
        insertPosition
    ) +
    adminReviewRoutes +
    source.slice(
        insertPosition
    );

/* ---------------------------------------------------------
   SAVE
--------------------------------------------------------- */

fs.writeFileSync(
    file,
    source,
    "utf8"
);

console.log("");
console.log("==========================================");
console.log("? ADMIN REVIEW ROUTES ADDED");
console.log("==========================================");
console.log("");
console.log("Added:");
console.log("GET   /api/admin/reviews");
console.log("PATCH /api/admin/reviews/:id");
console.log("");
console.log("Existing student review code was NOT changed.");
console.log("Existing public review code was NOT changed.");
console.log("");
console.log("==========================================");
