require("dotenv").config();

const mongoose = require("mongoose");
const readline = require("readline");
const bcrypt = require("bcryptjs");

const Admin = require("../database/models/Admin");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function askQuestion(question) {
    return new Promise((resolve) => {
        rl.question(question, resolve);
    });
}

async function createAdmin() {
    try {
        console.log("");
        console.log("==========================================");
        console.log("       PKS FOUNDATION ADMIN SETUP");
        console.log("==========================================");
        console.log("");

        if (!process.env.MONGODB_URI) {
            throw new Error(
                "MONGODB_URI is missing from your .env file."
            );
        }

        await mongoose.connect(process.env.MONGODB_URI);

        console.log("✅ Connected to MongoDB");
        console.log("");

        const usernameInput =
            await askQuestion("Enter admin username: ");

        const username =
            usernameInput.trim().toLowerCase();

        if (!username) {
            throw new Error(
                "Username cannot be empty."
            );
        }

        const password =
            await askQuestion(
                "Enter your new admin password: "
            );

        if (!password || password.length < 8) {
            throw new Error(
                "Password must contain at least 8 characters."
            );
        }

        const confirmPassword =
            await askQuestion(
                "Confirm your admin password: "
            );

        if (password !== confirmPassword) {
            throw new Error(
                "Passwords do not match."
            );
        }

        const existingAdmin =
            await Admin.findOne({ username });

        const passwordHash =
            await bcrypt.hash(password, 12);

        if (existingAdmin) {

            existingAdmin.passwordHash =
                passwordHash;

            existingAdmin.name =
                "Santosh Sir";

            existingAdmin.role =
                "administrator";

            existingAdmin.isActive =
                true;

            await existingAdmin.save();

            console.log("");
            console.log(
                "✅ Existing administrator password updated."
            );

        } else {

            await Admin.create({
                username,
                passwordHash,
                name: "Santosh Sir",
                role: "administrator",
                isActive: true
            });

            console.log("");
            console.log(
                "✅ New administrator account created."
            );
        }

        console.log("");
        console.log("Username:", username);
        console.log(
            "Password: securely stored as a hash"
        );
        console.log("");
        console.log(
            "🔐 Your password is NOT stored in frontend code."
        );
        console.log("");

    } catch (error) {

        console.error("");
        console.error(
            "❌ Admin setup failed:"
        );
        console.error(
            error.message
        );
        console.error("");

    } finally {

        rl.close();

        await mongoose.connection.close();

        console.log(
            "MongoDB connection closed."
        );
        console.log("");
    }
}

